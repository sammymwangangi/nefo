<?php

namespace App\Providers;
use Illuminate\Support\ServiceProvider;
use App\Discussion;
use App\Channel;
use View;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
      View::share('channels', Channel::all());
      View::share('discussions', Discussion::all());
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
