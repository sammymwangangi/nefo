@extends('layouts.app')

@section('content')
            <div class="card border-success mb-3" >

                <div class="card-header bg-success">
                    <h5 class="text-gray-dark"><i class="fa fa-user-o"></i>{{$d->user->name}}<b>({{$d->user->points}})</b>
                        <small class="text-white"><i class="fa fa-clock-o" style="font-size: 1.5rem;color: white;"></i> {{$d->created_at->diffForHumans()}} &nbsp;|&nbsp; {{$d->created_at->format(' H:i A')}}</small>
                        
                     </h5>

                     @if($d->hasBestAnswer())

                        <span class="btn btn-success btn-sm float-right">CLOSED</span>

                    @else

                        <span class="btn btn-danger btn-sm float-right">OPEN</span>

                    @endif

                    @if(Auth::id() == $d->user->id)
                        @if(!$d->hasBestAnswer())
                            <a href="{{route('discussions.edit', ['slug' => $d->slug])}}" class="btn btn-info btn-sm">Edit</a>
                        @endif                       
                    @endif

                    @if($d->is_being_watched_by_auth_user())
                        <a href="{{route('discussion.unwatch', ['id' => $d->id])}}" class="btn btn-light btn-sm">unwatch</a>
                    @else
                        <a href="{{route('discussion.watch', ['id' => $d->id])}}" class="btn btn-light btn-sm">watch</a>
                    @endif
                </div>

                <div class="card-body text-success text-center">
                    <h3> {{$d->title}}</h3>
                    <hr>

                    {!!Markdown::convertToHtml($d->content)!!}

                </div>
                <div class="card-footer bg-transparent border-success">
                    <a href="{{route('channel', ['slug' => $d->channel->slug])}}" class="btn btn-success btn-sm">{{$d->channel->title}}</a>
                    <button type="button" class="btn btn-light">{{$d->replies->count()}} <i class="fa fa-comments-o" style="font-size: 2rem;color: green;"></i></button>


                </div>
            </div>
            <hr>

            @if($best_answer)
                @if(Auth::id() == $d->user->id)
               <div class="card border-success mb-3" >

                <div class="card-header bg-success">
                    <h4>Best Answer</h4>
                  <i class="fa fa-user-o"></i>{{$best_answer->user->name}}<b>({{$best_answer->user->points}})</b>
                      
                 

                   <span class="float-right">(as selected by {{$d->user->name}})</span>

                </div>

                <div class="card-body text-success text-center">

                    <p> {{$best_answer->content}}</p>
                </div>
                
            </div> 
                @endif
            @endif

            <div class="container"><h2> <small>Replies</small></h2></div>
            @foreach($d->replies as $r)
            <div class="card border-success mb-3" >

                <div class="card-header bg-success">
                  <h5 class="text-gray-dark"><i class="fa fa-user-o"></i>{{$d->user->name}}<b>({{$r->user->points}})</b>
                      <small class="text-white"><i class="fa fa-clock-o" style="font-size: 1.5rem;color: white;"></i> {{$d->created_at->diffForHumans()}} &nbsp;|&nbsp; {{$d->created_at->format(' H:i A')}}</small>

                   </h5>

                </div>

                <div class="card-body text-success text-center">

                    {!!Markdown::convertToHtml ($r->content)!!}
                </div>
                <div class="card-footer bg-transparent border-success">
                    @if($r->is_liked_by_auth_user())
                        <a href="{{ route('reply.unlike', ['id' => $r->id ]) }}" class="btn btn-danger btn-sm">Unlike</a>
                    @else
                        <a href="{{ route('reply.like', ['id' => $r->id ]) }}" class="btn btn-success btn-sm">Like<span class="badge">{{$r->likes->count()}}</span></a>
                    @endif

                    @if(!$best_answer)
                        @if(Auth::id() == $d->user->id)
                            <span class="float-right"><a href="{{ route('discussion.best.answer', ['id' => $r->id])}}" class="btn btn-success btn-sm">Mark as best answer</a></span>
                        @endif
                    @endif

                    @if(Auth::id() == $r->user->id)
                        @if(!$r->best_answer)
                            <span class="float-right"><a href="{{ route('reply.edit', ['id' => $r->id])}}" class="btn btn-success btn-sm">Edit</a></span>
                        @endif
                    @endif
                </div>
            </div>

            @endforeach


            <div class="card mb-3" >

                <div class="card-body text-success text-center">

                   <form action="{{ route('discussion.reply', ['id' => $d->id]) }}" method="POST">

                        @csrf

                        <div class="form-group">
                            <label for="reply">Leave a reply...</label>
                            <textarea name="reply" id="reply" cols="30" rows="10" class="form-control"></textarea>
                        </div>

                        <div class="form-group">
                            <button class="btn pull-2">Leave a reply</button>
                        </div>

                    </form>
                </div>

            </div>

@endsection
