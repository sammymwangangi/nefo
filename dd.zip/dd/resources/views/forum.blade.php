@extends('layouts.app')

@section('content')

            @if(count($discussions) > 0)
            @foreach($discussions as $d)
            <div class="card border-success mb-3" >

                <div class="card-header bg-success">
                    <h5 class="text-gray-dark"><i class="fa fa-user-o"></i>{{$d->user->name}}<b>({{$d->user->points}})</b>
                        <small class="text-white"><i class="fa fa-clock-o" style="font-size: 1.5rem;color: white;"></i> {{$d->created_at->diffForHumans()}} &nbsp;|&nbsp; {{$d->created_at->format(' H:i A')}}</small>
                     </h5>
                    
                    @if($d->hasBestAnswer())

                        <span class="btn btn-success btn-sm float-right">CLOSED</span>

                    @else

                        <span class="btn btn-danger btn-sm float-right">OPEN</span>

                    @endif
                </div>

                <div class="card-body text-success text-center">
                    <h3> {{$d->title}}</h3>
                    <p> {{str_limit($d->content, 50)}}</p>
                    <a href="{{route('discussion', ['slug' => $d->slug ])}}">Read More...</a>

                </div>
                <div class="card-footer bg-transparent border-success">
                    <a href="{{route('channel', ['slug' => $d->channel->slug])}}" class="btn btn-success btn-sm">{{$d->channel->title}}</a>
                    <button type="button" class="btn btn-light">{{$d->replies->count()}} <i class="fa fa-comments-o" style="font-size: 2rem;color: green;"></i></button>

                </div>
            </div>
            @endforeach

    <br>
    <div class="row justify-content-center">
    
           
                {{$discussions->links()}}

    </div>
    @else
    <div class="alert alert-danger" role="alert">
      <h1 class="display-4">No discussions found!!!</h1>
    </div>
    @endif
@endsection
