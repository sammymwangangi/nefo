<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>NexForum</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.12.0/styles/atom-one-dark.min.css" rel="stylesheet">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <style type="text/css">
        .jumbotron {
            color: #15e84d;
        }

        .display-4 {
            font-weight: bold;
            text-shadow: 1rem 1rem 4rem;

        }
/*=========================
  Icons
 ================= */

/* footer social icons */
ul.social-network {
    list-style: none;
    display: inline;
    margin-left:0 !important;
    padding: 0;
}
ul.social-network li {
    display: inline;
    margin: 0 5px;
}


/* footer social icons */
.social-network a.icoGithub:hover {
    background-color: black;
}
.social-network a.icoFacebook:hover {
    background-color:#3B5998;
}
.social-network a.icoTwitter:hover {
    background-color:#33ccff;
}
.social-network a.icoGoogle:hover {
    background-color:#BD3518;
}

.social-network a.icoGithub:hover i, .social-network a.icoFacebook:hover i, .social-network a.icoTwitter:hover i,
.social-network a.icoGoogle:hover i, {
    color:#fff;
}
a.socialIcon:hover, .socialHoverClass {
    color:#44BCDD;
}

.social-circle li a {
    display:inline-block;
    position:relative;
    margin:0 auto 0 auto;
    -moz-border-radius:50%;
    -webkit-border-radius:50%;
    border-radius:50%;
    text-align:center;
    width: 30px;
    height: 30px;
    font-size:20px;
}
.social-circle li i {
    margin:0;
    line-height:30px;
    text-align: center;
}

.social-circle li a:hover i, .triggeredHover {
    -moz-transform: rotate(360deg);
    -webkit-transform: rotate(360deg);
    -ms--transform: rotate(360deg);
    transform: rotate(360deg);
    -webkit-transition: all 0.2s;
    -moz-transition: all 0.2s;
    -o-transition: all 0.2s;
    -ms-transition: all 0.2s;
    transition: all 0.2s;
}
.social-circle i {
    color: #fff;
    -webkit-transition: all 0.8s;
    -moz-transition: all 0.8s;
    -o-transition: all 0.8s;
    -ms-transition: all 0.8s;
    transition: all 0.8s;
}

.social-circle a {
 background-color: darkgreen;   
}
    </style>


</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-dark bg-dark navbar-laravel fixed-top top-nav">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">

                   <h2><strong>NexForum</strong><i class="fa fa-comments mr-lg-4 fa-2x" style="color: green;"></i></h2>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><strong><?php echo e(__('Login')); ?></strong></a></li>
                            <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><strong><?php echo e(__('Register')); ?></strong></a></li>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <form class="form-inline">
                      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </nav>
            <div class="jumbotron jumbotron-fluid text-center bg-dark">
            <div class="container">
              <h2 class="display-4" style="margin-top: 5rem;">Connect with NexForum</h2>
              <p>&#8220;A web application where developers interact with other developers,to ask questions,update others on upcoming technologies and solve problems together.Both for newbies and advanced developers. &#8221;</p>
            </div>
                </div>
        <?php if($errors->count() > 0): ?>
            <ul class="list-group-item">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item text-danger">
                        <?php echo e($error); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <br>
        <?php endif; ?>
        <br>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <a href="<?php echo e(route('discussion.create')); ?>" class="form-control btn btn-success">Ask a Question</a>
                    <br><br>
                    <div class="card">
                      <div class="card-header text-center">
                        <h5><a href="/forum"> Home </a></h5>
                      </div>
                    </div>
                    <br>
                    <div class="card">
                      <div class="card-header">
                        SELECT A FILTER
                      </div>
                      <ul class="list-group list-group-flush">
                        <?php if(Auth::check()): ?>
                        <li class="list-group-item">
                            <a href="/forum?filter=me"> My discussions </a>

                        </li>
                        <?php endif; ?>

                        <li class="list-group-item">
                            <a href="/forum?filter=solved"> Solved </a>
                        </li>
                        <li class="list-group-item">
                            <a href="/forum?filter=unsolved"> Unsolved </a>
                        </li>
                      </ul>
                    </div>
                    <br>
                    <?php if(Auth::check()): ?>
                    <?php if(Auth::user()->admin): ?>
                    <div class="card">
                      <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <a href="/channels">All Channels</a>
                            <span class="float-right badge badge-pill badge-success"><?php echo e($channels->count()); ?> </span>
                        </li>
                      </ul>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                    <br>
                    <div class="card">
                      <div class="card-header">
                        OR PICK A CHANNEL
                      </div>
                      <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(route('channel', ['slug' => $channel->slug])); ?>"> <?php echo e($channel->title); ?> </a>
                            <span class="float-right badge badge-pill badge-success"><?php echo e($channel->discussions->count()); ?> </span>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </ul>
                    </div>
                    <br>
                </div>
                <div class="col-md-8">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
            <!-- Footer -->
    <footer class="footer bg-dark text-white">

        <!-- Social Icons -->
        <div class="bg-faded">
            <div class="container">
                <div class="row py-4">
                    <div class="col-md-6 col-lg-7">
                        <h4 class="mb-0 white-text">Get connected with us on social networks!</h4>
                    </div>
                    <div class="col-md-6 col-lg-5 text-right">
                        <a href=""><i class="fa fa-facebook white-text mr-lg-4 fa-2x"> </i></a>
                        <a href=""><i class="fa fa-twitter white-text mr-lg-4 fa-2x"> </i></a>
                        <a href=""><i class="fa fa-google-plus white-text mr-lg-4 fa-2x"> </i></a>
                        <a href=""><i class="fa fa-linkedin white-text mr-lg-4 fa-2x"> </i></a>
                        <a href=""><i class="fa fa-instagram white-text mr-lg-4 fa-2x"> </i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Social Icons -->

        <!-- Footer Links -->
        <div class="container pt-5 pb-2">
            <div class="row">

                <div class="col-md-3 col-lg-4 col-xl-3">
                    <h4>NEX FORUM</h4>
                    <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25">
                    <p>
                        An application where developers interact with other developers,to ask questions,update others on upcoming technologies and solve problems together.Both for newbies and advanced developers.
                    </p>
                </div>



                <div class="col-md-3 col-lg-2 col-xl-2 mx-auto">
                    <h4>Registered?</h4>
                    <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25">
                    <p><a class="nav-link text-white" href="<?php echo e(route('login')); ?>"><strong><?php echo e(__('Login')); ?></strong></a></li></p>
                    <p><a class="nav-link text-white" href="<?php echo e(route('register')); ?>"><strong><?php echo e(__('Register')); ?></strong></a></li></p>
                </div>

                <div class="col-md-4 col-lg-3 col-xl-3">
                    <h4>Contact</h4>
                    <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25">
                    <p><i class="fa fa-home mr-3"></i>Nairobi CBD</p>
                    <p><i class="fa fa-envelope mr-3"></i> info@nextechs.co.ke</p>
                    <p><i class="fa fa-phone mr-3"></i> +254717503802</p>

                </div>

            </div>
        </div>
        <!-- Footer Links-->

        <hr class="bg-white mx-4 mt-2 mb-1">

        <!-- Copyright-->
        <div class="container-fluid">
            <p class="text-center m-0 py-1">
                © 2018 Copyright Nexforum |  Courtesy of  <a href="https://nextechs.co.ke/" class="text-white">NexTechs</a>
            </p>
        </div>
        <!-- Copyright -->

    </footer>
    <!-- Footer -->
    </div>
    <!-- scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        <?php if(Session::has('success')): ?>
            toastr.success('<?php echo e(Session::get('success')); ?>')
        <?php endif; ?>
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.12.0/highlight.min.js"></script>
    <script>hljs.initHighlightingOnLoad();</script>
</body>
</html>
