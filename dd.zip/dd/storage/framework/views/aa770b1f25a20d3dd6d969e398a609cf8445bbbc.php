<?php $__env->startSection('content'); ?>   
            <div class="card border-success mb-3" >

               <div class="card-header bg-success">
                    <h5 class="text-gray-dark"><i class="fa fa-user-o"></i><?php echo e($d->user->name); ?>

                        <small class="text-white"><i class="fa fa-clock-o" style="font-size: 1.5rem;color: white;"></i> <?php echo e($d->created_at->diffForHumans()); ?> &nbsp;|&nbsp; <?php echo e($d->created_at->format(' H:i A')); ?></small>
                     </h5>

                    <?php if($d->is_being_watched_by_auth_user()): ?>
                        <a href="<?php echo e(route('discussion.unwatch', ['id' => $d->id])); ?>" class="btn btn-success btn-sm"><span class="float-right">unwatch</span></a>
                    <?php else: ?>
                        <a href="<?php echo e(route('discussion.watch', ['id' => $d->id])); ?>" class="btn btn-success btn-sm">watch</a>
                    <?php endif; ?>
                </div>

                <div class="card-body text-success text-center">
                    <h3> <?php echo e($d->title); ?></h3>
                    <hr>
                    <p> <?php echo e($d->content); ?></p>
                </div>
                <div class="card-footer bg-transparent border-success">
                    <a href="<?php echo e(route('channel', ['slug' => $d->channel->slug])); ?>" class="btn btn-success btn-sm"><?php echo e($d->channel->title); ?></a>
                    <button type="button" class="btn btn-light"><?php echo e($d->replies->count()); ?> <i class="fa fa-comments-o" style="font-size: 2rem;color: green;"></i></button>

                </div>
            </div>

            <?php $__currentLoopData = $d->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card border-success mb-3" >

                <div class="card-header bg-success">
                    <h5 class="text-gray-dark"><i class="fa fa-user-o"></i><?php echo e($r->user->name); ?> </h5>
                    <small class="text-white"><i class="fa fa-clock-o" style="font-size: 1.5rem;color: white;"></i> <?php echo e($d->created_at->diffForHumans()); ?> &nbsp;|&nbsp; <?php echo e($r->created_at->format(' H:i A')); ?></small>
                    
                </div>

                <div class="card-body text-success text-center">
                  
                    <p> <?php echo e($r->content); ?></p>
                </div>
                <div class="card-footer bg-transparent border-success">
                    <?php if($r->is_liked_by_auth_user()): ?>
                        <a href="<?php echo e(route('reply.unlike', ['id' => $r->id ])); ?>" class="btn btn-danger btn-sm">Unlike</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('reply.like', ['id' => $r->id ])); ?>" class="btn btn-success btn-sm">Like<span class="badge"><?php echo e($r->likes->count()); ?></span></a>
                    <?php endif; ?>
                    

                </div>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="card mb-3" >

                <div class="card-body text-success text-center">
                  
                   <form action="<?php echo e(route('discussion.reply', ['id' => $d->id])); ?>" method="POST">

                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="reply">Leave a reply...</label>
                            <textarea name="reply" id="reply" cols="30" rows="10" class="form-control"></textarea>
                        </div>

                        <div class="form-group">
                            <button class="btn pull-2">Leave a reply</button>
                        </div>

                    </form>
                </div>

            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>