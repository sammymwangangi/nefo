<?php $__env->startSection('content'); ?>
            <?php if(count($discussions) > 0): ?>
            <?php $__currentLoopData = $discussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card border-success mb-3" >

                <div class="card-header bg-success">
                    <h5 class="text-gray-dark"><i class="fa fa-user-o"></i><?php echo e($d->user->name); ?> <b>(<?php echo e($d->user->points); ?>)</b>
                        <small class="text-white"><i class="fa fa-clock-o" style="font-size: 1.5rem;color: white;"></i> <?php echo e($d->created_at->diffForHumans()); ?> &nbsp;|&nbsp; <?php echo e($d->created_at->format(' H:i A')); ?></small>
                     </h5>

                </div>

                <div class="card-body text-success text-center">
                    <h3> <?php echo e($d->title); ?></h3>
                    <p> <?php echo e(str_limit($d->content, 50)); ?></p>
                    <a href="<?php echo e(route('discussion', ['slug' => $d->slug ])); ?>">Read More...</a>

                </div>
                <div class="card-footer bg-transparent border-success">
                    <a href="<?php echo e(route('channel', ['slug' => $d->channel->slug])); ?>" class="btn btn-success btn-sm"><?php echo e($d->channel->title); ?></a>
                    <button type="button" class="btn btn-light"><?php echo e($d->replies->count()); ?> <i class="fa fa-comments-o" style="font-size: 2rem;color: green;"></i></button>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <br>
    <?php else: ?>
    <div class="alert alert-danger" role="alert">
      <h1 class="display-4">No discussions found!!!</h1>
    </div>
        
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>